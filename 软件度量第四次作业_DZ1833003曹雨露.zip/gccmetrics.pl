#为gcc计算如下度量值N V D E L T 
#N:operators and operands 运算符和操作数
#V: Nlog2μ μ指运算符和操作数种类的总和 potential Volume
#D:1/L  difficulty
#E:V/L  effort
#L: V*/V  V*=(2+μ2*)log2(2+μ2*)  program level  
#T: E/S programming time
use Understand;
use warnings;
$db=Understand::open("gcc.udb");
open ($file,'>', 'output.csv') or die "Could not open file '$filename' $!";
print $file "funcname",',',"N",',',"V",',',"D",',',"E",',',"L",',',"T","\n";
foreach $func ($db->ents("function ~unknown ~unresolved"))
{
	$funcname=$func->name();
    $fileref=$func->ref("definein");
    next if (!defined $fileref);
	$lexer=$func->lexer();
	$startline=$fileref->line();
	$endline=$fileref->line()+$func->metric("CountLineCode");
	$countinput=$func->metric("CountInput");
	$countoutput=$func->metric("CountOutput");
	my %n1=();
	my %n2=();
	my $N1=0;
	my $N2=0;
	my $N=0;
	my $miu_temp=0;
	foreach my $lexeme ($lexer->lexemes($startline,$endline))
	{	
		
		if(($lexeme->token eq "operator") || ($lexeme->token eq "Keyword") || ($lexeme->token eq "Punctuation"))
		{
			if ($lexeme->text()!~ /[)}\]]/)
			{
				$n1{$lexeme->text()}=1;
				$N1++;
			}
		}
		elsif (($lexeme->token eq "Identifier") || ($lexeme->token eq "Literal")|| ($lexeme->token eq "String"))
		{
			$n2{$lexeme->text()}=1;
			$N2++;
		}
		
		
	}
	eval{   #因为有些函数会报错
		$n1 = scalar(keys(%n1));
		$n2 = scalar(keys(%n2));
		$N=$N1+$N2;
		$V=$N*log($n1+$n2)/log(2);
		$count = $countinput + $countoutput;
		$V_temp=(2+$count)*(log(2+$count))/log(2);
		$L=$V_temp/$V;
		#$D=1/$L;
		$D=$n1/2*$N2/$n2;
		$E=$V/$L;
		$T=$E/18;
		print $file $funcname,',',$N,',',$V,',',$D,',',$E,',',$L,',',$T,"\n";
		print '---------',$n1+$n2,"\n";
	};
	if($@)
	{
		print $funcname,',',"error occurd:$@\n";
	}
	
}
$db->close()
