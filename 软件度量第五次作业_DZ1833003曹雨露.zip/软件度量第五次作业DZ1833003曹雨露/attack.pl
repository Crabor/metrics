=pod
攻击面：入口点和出口点作为攻击面，具体类型：出口、入口、channel、不可信任的数据、M、C、I
确定damage potential-effort ratio  本作业只到方法级别，即入口出口
使用工具：cflow建立调用关系
=cut

use warnings;
use File::Basename;
use CGI qw/:standard/;


@Input = qw(canonicalize_file_name   catgets   confstr   ctermid  
ctermid   cuserid  dgettext  dngettext  fgetc  fgetc unlocked 
fgets  fgets unlocked  fpathconf  fread  fread unlocked  fs-
canf  getc  getchar  getchar unlocked  getc unlocked 
get current dir name  getcwd  getdelim  getdelim  __getdelim 
getdents  getenv  gethostbyaddr  gethostbyname  gethostby-
name2  gethostent  gethostid  getline  getline  getlogin  get-
login_r  getmsg  getopt  _getopt_internal  getopt_long getopt_long_only  getpass  getpmsg  gets  gettext  getw  getwd 
ngettext  pathconf  pread  pread64  ptsname  ptsname_r 
read  readdir  readlink  readv  realpath  recv  recv from 
recvmesg  scanf  __secure_getenv  signal  sysconf  ttyname 
ttyname_r  vfscanf  vscanf);
@Output = qw(dprintf  fprintf  fputc  fputchar unlocked 
fputc unlocked  fputs  fputs unlocked  fwrite  fwrite unlocked 
perror  printf  psignal  putc  putchar  putc_unlocked  putenv 
putmsg  putpmsg  puts  putw  pwrite  pwrite64  send  sendmsg 
sendto  setenv  sethostid  setlogin  ungetc  vdprintf  vfprintf 
vsyslog  write  writev);
$scalarI = @Input;
$scalarO = @Output;


print $scalarI,"\n";
print $scalarO ,"\n";
open ($file,'>', 'result.csv') or die "Could not open file '$filename' $!";
print $file "ftpd",",","DEP",",","DExP","\n";
@names=();
@filenames = ();
@files = ();
$path = "/home/cyl/Desktop/metrics/wu-ftpd-2.6.2/src";
scan_file($path);
$entrypoints = 0;
$exitpoints = 0 ;
foreach $funcname(@names)
{
    if (grep m/$funcname/,@Input)
    {
        $entrypoints += 1;
    }
    if (grep m/$funcname/,@Output)
    {
        $exitpoints += 1;
    }
}
print $entrypoints,",",$exitpoints,"\n";
print $file 'proftpd',",",$entrypoints,",",$exitpoints,"\n";

@names=();
@filenames = ();
@files = ();
$path = "/home/cyl/Desktop/metrics/wu-ftpd-2.6.2";
scan_file($path);
$entrypoints = 0;
$exitpoints = 0 ;
foreach $funcname(@names)
{
    if (grep m/$funcname/,@Input)
    {
        $entrypoints += 1;
    }
    if (grep m/$funcname/,@Output)
    {
        $exitpoints += 1;
    }
}
print $entrypoints,",",$exitpoints,"\n";
print $file 'wu-ftpd',",",$entrypoints,",",$exitpoints,"\n";

sub scan_file{
    my @files = glob(@_[0]);
    foreach (@files){
        if(-d $_){
            my $path = "$_/*";
            scan_file($path);
        }elsif(-f $_){
            my (undef,undef,$ftype)=fileparse($_,qr"\..*");
            next if ($ftype ne ".c" && $ftype ne ".h" );  #如果不包含
            print "$_\n";
            push(@filesnames,$_);
            system("cflow -x -b -o /home/cyl/Desktop/metrics/output2.txt ".$_ );  #得到该文件
            eval{
                open d,"< /home/cyl/Desktop/metrics/output2.txt" or die "Could not open file";
                while(<d>){
                    @temp = split(/\s/,$_);
                    push(@names,$temp[0]);
                }
                system("rm "."/home/cyl/Desktop/metrics/output2.txt");  #将该文件删掉
                # print "has delete the file\n";
            };
            if($@)
                {
                    print "error occurd:$@\n";
            }
            
        }
    }
}