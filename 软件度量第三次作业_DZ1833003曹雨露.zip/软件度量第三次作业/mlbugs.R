dataset <- read.csv("E:\\teamworks\\softwaremetrics\\R\\xalan-2.4.csv",header=T)
newdata <- dataset[c("wmc","dit","noc","cbo","rfc","lcom","bug")]   #六变量缺陷影响分析
library(e1071)
library(kknn)
library(stats)
library(rpart)
library(randomForest)
library(nnet)
library(BayesTree)
library(adabag)
library(pROC)
library(caret)
auc_list<-data.frame(naiveBayes=0,svm=0,knn=0,kmeans=0,rpart=0,randomforest=0,boosting=0,logis=0,nnet=0,bagging=0)
auc_list=auc_list[-1,] #删除一行
label <- NULL
for(x in newdata$bug) {
  if(x > 0)
    label <-c(label, as.integer(1))
  else
    label <-c(label, as.integer(0))
}
newdata$labels <- label
newdata <- newdata[,-7]
myFormula <- labels~ wmc + dit + noc + cbo + rfc+ lcom   #前者是因变量，后面是多自变量
for (j in 1:10)
{
  for (m in 1:10) 
  {  
    folds <- createFolds(y=newdata$labels,k=10)
    print(j)
    print('----------')
    print("***测试集精确度***")
    #十折交叉验证
    for(i in 1:10)
    {
      fold_test <- newdata[folds[[i]],]   #取folds[[i]]作为测试集
      fold_train <- newdata[-folds[[i]],]   # 剩下的数据作为训练集
      if (j!=2)
      {
      fold_train$labels <- as.factor(fold_train$labels)
      }
      fold_model<-switch(j,
                         e1071::naiveBayes(formula=myFormula,data=fold_train),  #朴素贝叶斯算法
                         e1071::svm(myFormula,fold_train,probability=TRUE),   #svm算
                         kknn(myFormula,train = fold_train,test = fold_test,k=7),#k近邻算法
                         kmeans(newdata,5,nstart=24), #kmeans聚类算法
                         rpart(myFormula,data=fold_train,control = rpart.control(minsplit = 10)),  #CART决策树算法
                         randomForest(myFormula,fold_train),  #随机森林算法
                         boosting(myFormula,fold_train,boos=TRUE, mfinal=3), #Boosting分类算法
                         multinom(myFormula,fold_train),                     #逻辑回归
                         nnet(myFormula,fold_train,size=3),       #神经网络
                         bagging(formula=myFormula,data=fold_train,mfinal = 10) #bag分类算法
                        )
      if (j==1)
      {
        fold_predict<-predict(fold_model,newdata=fold_test,type="raw")
        fold_predict <- fold_predict[,2]
      }
      else if (j==2)
      {
        fold_predict<-predict(fold_model,newdata=fold_test,probability = TRUE)
      }
      else if(j==4)
      {
        temp<-fitted(fold_model,method="centers")
        fold_predict=temp[folds[[i]],7]
      }
      else if(j==7)
      {
        temp<-predict.boosting(fold_model,newdata=fold_test,type="prob")
        fold_predict<-temp$prob
        fold_predict<-fold_predict[,2]
        
      }
      else if(j==8)
      {
        fold_predict<-predict(fold_model,newdata=fold_test,type="prob")  #对于神经网络
      }
      else if(j==9)
      {
        fold_predict<-predict(fold_model,newdata=fold_test,type="raw")
      }
      else if(j==10)
      {
        temp<-predict.bagging(fold_model,newdata=fold_test)
        fold_predict<-temp$prob
        fold_predict<-fold_predict[,2]
      }
      else
      {
        fold_predict<-predict(fold_model,newdata=fold_test,type="prob")
        fold_predict <- fold_predict[,2]
      }
      fold_predict<-as.numeric(as.character(fold_predict))  #有些转换是factor，正确将其转为numeric
      print(fold_predict)
      #print(fold_test$bug)
      #fold_error = fold_predict-fold_test$labels
      #求解AUC
      
      roctemp<-pROC::multiclass.roc(fold_test$labels,fold_predict,levels=base::levels(as.factor(fold_test$labels)))
      auctemp<-pROC::auc(roctemp)
      print(as.numeric(auctemp))  #as.numeric转数字
      #求解CE
      auc_list[(m-1)*10+i,j]<-as.numeric(auctemp)  #
    }
    
    print('-------')
  }
}

auc_mean<-apply(auc_list,2,mean)
auc_max<-max(auc_mean)
print(auc_mean)  #平均性能
auc_list[101,]<-auc_mean
for (t in 1:10)
{
  auc_list[102,t]<-(auc_mean[[t]]-0.5)/(auc_max-0.5)
  
}
print( auc_list[102,])
write.table(auc_list,file='perform.csv',sep =",", row.names =FALSE, col.names =TRUE, quote =TRUE)

library(scmamp)
library(pheatmap)
data<-auc_list
data<-data[1:100,]
#CD图

png(file="plotCD.png")
plotCD(data,alpha=0.05,cex=1.25)
dev.off()
#
png(file="drawAlgorithmGraph.png")
pv.matrix <- friedmanAlignedRanksPost(data=data[,1:9], control=NULL)
pv.adj <- adjustBergmannHommel(pv.matrix)
r.means <- colMeans(rankMatrix(data[,1:9]))
drawAlgorithmGraph(pvalue.matrix=pv.adj, mean.value=r.means, alpha=0.05,font.size=10, node.width=3, node.height=1)
dev.off()
#heatmap

heatdata<-read.csv('perform.csv',sep=",",header = T)
png(file="heatmap.png")
pheatmap(heatdata)
dev.off()

rm(list=ls())



