#library(Hmisc)
library(moments)
dataset <- read.csv("E:\\teamworks\\softwaremetrics\\R\\xalan-2.4.csv",header=T)
#View(dataset)
newdata <- dataset[c("wmc","dit","noc","cbo","rfc","lcom")]
bugdata<-dataset["bug"]
auc_list<-data.frame(wmc=0,dit=0,noc=0,cbo=0,rfc=0,lcom=0)
auc_list=auc_list[-1,] #ɾ��һ��

auc_list[1:3,]<-apply(newdata,2,quantile,c(0.25,0.5,0.75))	  
auc_list[4,]<-apply(newdata,2,max)	   
auc_list[5,]<-apply(newdata,2,mean)	   
auc_list[6,]<-apply(newdata,2,moments::skewness)	  
auc_list[7,]<-apply(newdata,2,moments::kurtosis)	

for(i in 1:6){
  pearsond<-cor.test(newdata[,i],bugdata[,1],alternative=c("two.sided"),method = c("pearson"),conf.level=0.95)
  print(as.numeric(pearsond$estimate))
  print(as.numeric(pearsond$p.value))
  auc_list[8,i]<-as.numeric(pearsond$estimate)
  auc_list[9,i]<-as.numeric(pearsond$p.value)
  pearsond<-cor.test(newdata[,i],bugdata[,1],alternative=c("two.sided"),method = c("spearman"),conf.level=0.95)
  print(as.numeric(pearsond$estimate))
  print(as.numeric(pearsond$p.value))
  auc_list[10,i]<-as.numeric(pearsond$estimate)
  auc_list[11,i]<-as.numeric(pearsond$p.value)
}

row.names(auc_list)<-c("25%","50%","75%","max","mean","skewness","kurtosis","pearson","pvalue_pearson","spearman","pvalue_spearman")
write.table(auc_list,file='info.csv',sep =",", row.names =TRUE, col.names =TRUE, quote =FALSE)
